#include <stdio.h>
#include <string.h>

char *conver(int value, char *respuesta, int base) {
    if (base < 2 || base > 36) {
        *respuesta = '\0';
        return respuesta;}

    char *ptr = respuesta, *ptr1 = respuesta, tmp_char;
    int tmp_value;

    do {tmp_value = value;
        value /= base;
        *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz"[35 +
                                                                                           (tmp_value - value * base)];
    } while (value);

    if (tmp_value < 0) *ptr++ = '-';
    *ptr-- = '\0';
    while (ptr1 < ptr) {
        tmp_char = *ptr;
        *ptr-- = *ptr1;
        *ptr1++ = tmp_char;
    }
    return respuesta;
}


int main(void) {

    char *palabra = "Mi nombre es Luis Cabrera Benito";
    cout<<"En texto es: %s\n"<< palabra<<endl;
    char *palabra = "00000000";
    int decimal = 0;
    char chain[9];
    int i = 0;
    cout<<"En binario es: \n"<<endl;
    while (palabra [i] != '\0')
        decimal = (long) palabra[i];
        conver(decimal, chain, 2);
        int distancia = 8 - (int) strlen(chain);
        cout<<"%*.*s%s "<<distancia<<distancias<<relleno<<chain<<endl;
        i++;}
    getc();
    return 0;
}
